package cs5004.animator.model;

/**
 * Represents the shape types.
 */
public enum ShapeType {

  Oval,Rectangle;
}
