package cs5004.animator.model;

/**
 * Represents the animation types.
 */
public enum AnimationElement {
  COLORCHANGE, MOVE, SCALE;
}